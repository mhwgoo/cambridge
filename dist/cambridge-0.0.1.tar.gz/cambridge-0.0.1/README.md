cambridge
Terminal Version of Cambridge Dictionary from https://dictionary.cambridge.org
