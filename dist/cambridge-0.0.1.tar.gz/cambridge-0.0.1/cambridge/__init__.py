"""
This is the terminal version of cambridge dictionary from https://dictionary.cambridge.org.
"""

__version__ = "0.0.1"
